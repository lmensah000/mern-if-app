const config = {
  apiKey: "REPLACE ME",
  authDomain: "REPLACE ME",
  databaseURL: "REPLACE ME",
  storageBucket: "REPLACE ME",
  messagingSenderId: "REPLACE ME"
};
module.exports = config;
